1. write the graph file to "graph.txt"
2. place "graph.txt" in the same folder as "lp-dag.py"
3. run "python lp-dag.py"
